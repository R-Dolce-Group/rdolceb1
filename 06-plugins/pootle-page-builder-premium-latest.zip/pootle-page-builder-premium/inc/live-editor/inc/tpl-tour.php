<div id="ppb-tour-dialog" style="display: none;"></div>

<style>
	#ppb-tour-dialog .dashicons {
		vertical-align: middle;
	}
	#ppb-tour-dialog .tour-header {
		background: #ef4832;
		color: #fff;
		border-color: #ef4832;
	}

	#ppb-tour-dialog .tour-footer {
		color: #e04030;
	}

	#ppb-tour-dialog .dashicons {
		height: auto;
		width: auto;
		font-size: 1.24em;
	}
	#ppb-tour-dialog .dashicons-lightbulb {
		margin-left: -5px;
	}
	#ppb-tour-dialog .tour-footer .dashicons {
		margin: -2px -2px 0 -1px;
	}
	#ppb-tour-dialog .tour-footer .dashicons-controls-play {
		margin-right: -5px;
	}
	.tour-dialog .tour-header h3 {
		font-size: 22px;
		font-weight: normal;
	}
	.tour-dialog .tour-footer a {
		font-weight: normal;
	}
</style>