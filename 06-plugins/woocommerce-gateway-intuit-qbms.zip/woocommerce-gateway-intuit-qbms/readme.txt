=== WooCommerce Intuit Payments Gateway ===
Author: skyverge
Tags: woocommerce
Requires at least: 4.1
Tested up to: 4.8.3

Accept credit cards in WooCommerce with the Intuit Payments or Legacy QBMS gateway

See http://docs.woothemes.com/document/woocommerce-intuit-qbms/ for full documentation.

== Installation ==

1. Upload the entire 'woocommerce-gateway-intuit-qbms' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
