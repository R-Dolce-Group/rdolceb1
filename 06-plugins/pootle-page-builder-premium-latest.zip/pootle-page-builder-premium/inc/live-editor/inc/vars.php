<?php
/**
 * Created by PhpStorm.
 * User: shramee
 * Date: 2/2/16
 * Time: 7:48 PM
 */

$ppble_new_live_page = array (
	'widgets' => array (
		array (
			'text' => "<h2>Hello<!--USER-->,</h2><p>I am your first row, go ahead, edit me and make me cool...</p>",
			'info' => array (
				'class' => 'Pootle_PB_Content_Block',
				'grid' => 0,
				'style' => '{"background-color":"","background-transparency":"","text-color":"","border-width":"","border-color":"","padding":"","rounded-corners":"","inline-css":"","class":"","wc_prods-add":"","wc_prods-attribute":"","wc_prods-filter":null,"wc_prods-ids":null,"wc_prods-category":null,"wc_prods-per_page":"","wc_prods-columns":"","wc_prods-orderby":"","wc_prods-order":""}',
				'cell' => 0,
				'id' => 0,
			),
		),
    ),
    'grids' => array (
		array (
			'id' => 0,
            'cells' => 1,
            'style' => array (
				'background' => '',
				'background_image' => '',
                'background_image_repeat' => '',
                'background_image_size' => 'cover',
                'background_parallax' => '',
                'background_toggle' => '',
                'bg_color_wrap' => '',
                'bg_image_wrap' => '',
                'bg_mobile_image' => '',
                'bg_overlay_color' => '',
                'bg_overlay_opacity' => '0.5',
                'bg_video' => '',
                'bg_video_wrap' => '',
                'bg_wrap_close' => '',
                'class' => '',
                'col_class' => '',
                'col_gutter' => '1',
                'full_width' => '',
                'hide_row' => '',
                'margin_bottom' => '0',
                'margin_top' => '0',
                'row_height' => '0',
                'style' => '',
            ),
		)
    ),
    'grid_cells' => array (
		array (
			'grid' => 0,
	        'weight' => 1,
	        'id' => 0,
	    ),
    ),
);