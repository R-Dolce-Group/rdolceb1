/**
 * Plugin front end scripts
 *
 * @package pootle_page_builder_blog_customizer
 * @version 1.0.0
 */
jQuery(function ($) {

    //Put all jquery code in here

});