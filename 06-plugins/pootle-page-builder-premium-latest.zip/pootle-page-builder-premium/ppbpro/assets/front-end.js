/**
 * Plugin front end scripts
 *
 * @package Pootle_Page_Builder_Pro
 * @developer shramee <shramee.srivastav@gmail.com>
 */
jQuery(function ($) {

    //Put all jquery code in here

});