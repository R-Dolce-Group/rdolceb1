# ppb-blog-customizer-addon
Allows you to create beautiful pages with your WordPress blog posts in pootle page builder
