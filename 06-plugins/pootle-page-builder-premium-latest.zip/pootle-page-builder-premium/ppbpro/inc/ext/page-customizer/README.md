# page-customizer
Simple page customizer plugin for all themes
