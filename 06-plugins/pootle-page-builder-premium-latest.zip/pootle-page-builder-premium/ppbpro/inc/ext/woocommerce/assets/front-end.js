/**
 * Plugin front end scripts
 *
 * @package pootle_page_builder_for_WooCommerce
 * @version 0.1.0
 */
jQuery(function ($) {

    //Put all jquery code in here

});